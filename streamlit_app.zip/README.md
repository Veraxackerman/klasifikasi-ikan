# 🐟 Klasifikasi Kesegaran Ikan — Streamlit App

Aplikasi web klasifikasi kesegaran ikan menggunakan CNN MobileNetV2.

---

## 📁 Struktur Folder

```
project/
├── app.py               ← file utama aplikasi Streamlit
├── model_final.keras    ← model hasil training (copy dari output notebook)
├── requirements.txt     ← daftar library yang dibutuhkan
└── README.md
```

---

## 🚀 Cara Menjalankan (Lokal)

### 1. Siapkan Model
Salin file `model_final.keras` dari output Google Colab ke folder ini.
File tersebut dihasilkan oleh Cell 43 notebook dengan nama `model_final.keras`.

### 2. Install Library
```bash
pip install -r requirements.txt
```

### 3. Jalankan Aplikasi
```bash
streamlit run app.py
```

Aplikasi akan terbuka otomatis di browser: **http://localhost:8501**

---

## ☁️ Deploy ke Streamlit Cloud (Gratis)

1. Upload semua file ke **repository GitHub** (public)
2. Pastikan `model_final.keras` ikut di-upload
3. Buka **https://share.streamlit.io**
4. Klik **New app** → pilih repo → pilih `app.py` → **Deploy**

> ⚠️ Jika ukuran model > 100 MB, gunakan **Git LFS** untuk upload ke GitHub,
> atau simpan model di Google Drive dan load via `gdown` di dalam `app.py`.

---

## 📌 Catatan

- Model menerima input gambar berukuran **224 × 224 piksel** (diproses otomatis)
- Output: **Fresh** (segar) atau **Not Fresh** (tidak segar)
- Model dilatih pada 3 jenis ikan: Nila, Kembung, Tuna
